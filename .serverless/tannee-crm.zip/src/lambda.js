const serverless = require("serverless-http");
const app = require("./app");
// console.log("DEBUG - typeof app:", typeof app);
module.exports.handler = serverless(app);
