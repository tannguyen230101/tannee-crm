module.exports = {
    owner: 0,
    admin: 1
}